const API_KEY = 'sk_b9b8081edb5249e59ad1bb6a59588ffc';
export const API_URL = `https://cloud.iexapis.com/stable/stock/market/batch?symbols=AAPL,MSFT,TSLA,AMZN,META&types=chart&range=1m&last=30&token=${API_KEY}`;
